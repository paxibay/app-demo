﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Task3_MVC.Startup))]
namespace Task3_MVC
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
