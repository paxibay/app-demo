﻿using MvcInfrastructure.Domain;
using MvcInfrastructure.Repository;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Task3_MVC.Models
{
    public class ManageUserViewModel
    {
        public ManageUser ManageUser { get; set; }
    }

    public class LoginViewModel
    {
        public Login Login { get; set; }
    }

    public class RegisterViewModel
    {
        public Register Register { get; set; }

        [Display(Name = "Select Role")]
        public int? RoleId { get; set; }
        public IEnumerable<ListItem> Roles { get; set; }
        public IEnumerable<SelectListItem> RoleItems
        {
            get 
            {
                Roles = new List<ListItem>
                {
                    new ListItem {Id = 1, Name = "User"},
                    new ListItem {Id = 2, Name = "Admin"}
                };

                return new SelectList(Roles, Items.Id.ToString(), Items.Name.ToString()); 
            }
        }

        public ApplicationUser GetUser()
        {
            if (Register == null)
            {
                return null;
            }

            var user = new ApplicationUser()
            {
                UserName = Register.UserName,
                FirstName = Register.FirstName,
                LastName = Register.LastName,
                EmailAddress = Register.EmailAddress,
                IsActive = Register.IsActive
            };
            return user;
        }
    }

    public enum Items
    {
        Id,
        Name
    }
    public class ListItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
