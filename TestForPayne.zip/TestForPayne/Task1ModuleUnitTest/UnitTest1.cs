﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Task1_WPF.Module.Model;

namespace Task1ModuleUnitTest
{
    [TestClass]
    public class RssManagerUnitTest
    {
        private RssManagerModel manager;

        [TestInitialize]
        public void Start()
        {
            //http://www.snowball.be/SyndicationService.asmx/GetRss
            //http://feeds.feedburner.com/binkdotnu
            manager = new RssManagerModel();
            manager.Url = "http://feeds.feedburner.com/binkdotnu"; 
        }

        [TestCleanup]
        public void Finish()
        {
            manager.Dispose();
        }

        [TestMethod]
        public void Can_Get_Feed_Data_From_Internet()
        {
            var rssFeed = manager.GetFeed();
            Assert.IsNotNull(rssFeed, "Change Url and Try again");
        }
    }
}
