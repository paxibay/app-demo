﻿using Microsoft.Practices.Prism.MefExtensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition.Hosting;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Task1_WPF.Module;

namespace Task1_WPF
{
    public class AppBootstrapper : MefBootstrapper
    {
        /// <summary>
        /// Step1: Configure AggregateCatalog
        /// </summary>
        protected override void ConfigureAggregateCatalog()
        {
            base.ConfigureAggregateCatalog();
            this.AggregateCatalog.Catalogs.Add(new AssemblyCatalog(typeof(AppBootstrapper).Assembly));  //(this.GetType().Assembly)

            this.AggregateCatalog.Catalogs.Add(new AssemblyCatalog(typeof(Task1Module).Assembly));
        }

        /// <summary>
        /// Step2: Configure Container 
        /// </summary>
        protected override void ConfigureContainer()
        {
            base.ConfigureContainer();
        }

        /// <summary>
        /// Step3: Create Shell  
        /// </summary>
        protected override DependencyObject CreateShell()
        {
            return this.Container.GetExportedValue<Shell>();
        }

        /// <summary>
        /// Step4: InitializeShell 
        /// </summary>
        protected override void InitializeShell()
        {
            base.InitializeShell();
            App.Current.MainWindow = (Window)this.Shell;
            App.Current.MainWindow.Show();
        }
    }
}
