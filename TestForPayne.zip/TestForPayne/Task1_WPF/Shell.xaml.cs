﻿using System.ComponentModel.Composition;
using System.Windows;

namespace Task1_WPF
{
    [Export]
    public partial class Shell : Window 
    {
        public Shell()
        {
            InitializeComponent();
        }
    }
}

