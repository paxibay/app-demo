﻿using Microsoft.Practices.Prism.MefExtensions.Modularity;
using Microsoft.Practices.Prism.Modularity;
using Microsoft.Practices.Prism.Regions;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task1_WPF.Module.Views;

namespace Task1_WPF.Module
{

    [ModuleExport(typeof(Task1Module))]
    public class Task1Module : IModule
    {
        [Import]
        public IRegionManager rManager { private get; set; }

        #region IModule Members

        public void Initialize()
        {
            this.rManager.RegisterViewWithRegion("WorkspaceRegion", typeof(ContentView));
        }

        #endregion
    }
}
