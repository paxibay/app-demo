﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task1_WPF.Module.Model
{
    //[Serializable]
    public class RssItem
    {
        /// <summary>
        /// The publishing date.
        /// </summary>
        public DateTime Date;
         /// <summary>
        /// The title of the feed
        /// </summary>
        public string Title;

        /// <summary>
        /// A description of the content (or the feed itself)
        /// </summary>
        public string Description;

        /// <summary>
        /// The link to the feed
        /// </summary>
        public string Link;
    }
}