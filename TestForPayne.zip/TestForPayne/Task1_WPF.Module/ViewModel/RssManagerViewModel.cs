﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Input;
using Task1_WPF.Module.Model;

namespace Task1_WPF.Module.ViewModel
{
    public class RssManagerViewModel : ViewModelBase
    {
        private RssManagerModel _model;
        private RelayCommand _getFeedCommand;
        private ICollectionView _vmListView;

        private string _feedUrl;

        public RssManagerViewModel()
        {
            this._model = new RssManagerModel();
        }
        
        private void OnEntityListViewChanged(object sender, EventArgs e)
        {
            base.RaisePropertyChanged("CurrentFeed"); 
        }

        public Feed CurrentFeed
        {
            get
            {
                if (VmListView != null)
                {
                    return VmListView.CurrentItem as Feed;
                }
                return null;
            }
        }

        public ICollectionView VmListView
        {
            get
            {
                return _vmListView;
            }
            set
            {
                if (value == _vmListView)
                    return;

                _vmListView = value;
                base.RaisePropertyChanged("VmListView");
            }
        }

        public string FeedUrl
        {
            get
            {
                if (string.IsNullOrEmpty(_feedUrl))
                {
                    _feedUrl = "http://feeds.feedburner.com/binkdotnu";
                }
                return _feedUrl;
            }
            set
            {
                if (value == _feedUrl)
                    return;

                _feedUrl = value;
                base.RaisePropertyChanged("FeedUrl");
            }
        }

        public ICommand GetFeedCommand
        {
            get
            {
                if (_getFeedCommand == null)
                {
                    _getFeedCommand = new RelayCommand(
                        () => InitRssFeed(),
                        () => CanGetFeed()
                    );
                }
                return _getFeedCommand;
            }
        }

        public void InitRssFeed()
        {
            //http://www.snowball.be/SyndicationService.asmx/GetRss
            //http://feeds.feedburner.com/binkdotnu

            _model.Url = FeedUrl;

            try
            {
                _model.GetFeed();
            }
            catch (Exception)
            {
                return;
            }
            
            var vmList = _model.RssItems;
            
            //_vmListView = CollectionViewSource.GetDefaultView(vmList);

            List<Feed> feeds = new List<Feed>();
            for (int i = 0; i < vmList.Count; i++)
            {
                Feed feed = new Feed();
                feed.Title = vmList[i].Title;
                feed.Link = vmList[i].Link;
                feed.Date = vmList[i].Date.ToShortDateString();
                feed.Description = vmList[i].Description;
                feeds.Add(feed);
            }
            _vmListView = CollectionViewSource.GetDefaultView(feeds);
            _vmListView.CurrentChanged += OnEntityListViewChanged;

            base.RaisePropertyChanged("VmListView"); 
        }

        public bool CanGetFeed()
        {
            return !string.IsNullOrEmpty(FeedUrl);
        }
    }

    /// <summary>
    /// this class for showing only
    /// met some truble underlying List<RssItem> which cannot display
    /// </summary>
    public class Feed
    {
        public string Title { get; set; }
        public string Link { get; set; }
        public string Date { get; set; }
        public string Description { get; set; }
    }
}