﻿using Microsoft.AspNet.Identity;
using MvcInfrastructure.Repository;

namespace MvcInfrastructure.Service
{
    public interface IIdentityService
    {
        UserManager<ApplicationUser> UserManager { get; set; }
        bool AddUserToRole(string userId, string roleName);
        void ClearUserRoles(string userId);
        bool CreateRole(string name);
        bool CreateUser(global::MvcInfrastructure.Repository.ApplicationUser user, string password);
        bool RoleExists(string name);
    }
}
