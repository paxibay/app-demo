﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using MvcInfrastructure.Repository;

namespace MvcInfrastructure.Service
{
    public class IdentityService : IIdentityService
    {
        private readonly IdentityRepository _repo;

        public IdentityService()
        {
            this._repo = new IdentityRepository();
            UserManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(new ApplicationDbContext()));
        }

        public UserManager<ApplicationUser> UserManager { get; set; }

        public bool AddUserToRole(string userId, string roleName)
        {
            return _repo.AddUserToRole(userId, roleName);
        }

        public void ClearUserRoles(string userId)
        {
            _repo.ClearUserRoles(userId);
        }

        public bool CreateRole(string name)
        {
            return _repo.CreateRole(name);
        }

        public bool CreateUser(Repository.ApplicationUser user, string password)
        {
            return _repo.CreateUser(user, password);
        }

        public bool RoleExists(string name)
        {
            return _repo.RoleExists(name);
        }
    }
}
